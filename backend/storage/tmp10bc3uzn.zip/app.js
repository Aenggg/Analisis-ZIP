const API_BASE = "http://localhost:8000";

function render(box, data) {
  box.innerHTML = `
    <pre class="bg-slate-950 border border-slate-700 rounded p-3 overflow-x-auto whitespace-pre-wrap">
${JSON.stringify(data, null, 2)}
    </pre>`;
}

async function uploadFile() {
  const input = document.getElementById("uploadFileInput");
  const box = document.getElementById("uploadResult");

  if (!input.files.length) {
    box.innerHTML = "Pilih file ZIP terlebih dahulu.";
    return;
  }

  if (!input.files[0].name.toLowerCase().endsWith(".zip")) {
    box.innerHTML = "File harus berformat .zip.";
    return;
  }

  const fd = new FormData();
  fd.append("file", input.files[0]);

  box.innerHTML = "Memproses SHA-256, Merkle Tree, dan blockchain lightweight...";
  const res = await fetch(`${API_BASE}/upload`, {
    method: "POST",
    body: fd
  });
  render(box, await res.json());
}

async function verifyHash() {
  const hash = document.getElementById("verifyInput").value.trim();
  const box = document.getElementById("verifyResult");

  if (!hash) {
    box.innerHTML = "Hash SHA-256 wajib diisi.";
    return;
  }

  box.innerHTML = "Memverifikasi blockchain, tanda tangan, chunk, dan Merkle root...";
  const res = await fetch(`${API_BASE}/verify/${hash}`);
  render(box, await res.json());
}

async function registerNode() {
  const addr = document.getElementById("nodeAddressInput").value.trim();
  const box = document.getElementById("nodeResult");

  if (!addr) {
    box.innerHTML = "Node ID wajib diisi.";
    return;
  }

  const fd = new FormData();
  fd.append("address", addr);

  box.innerHTML = "Mendaftarkan peer...";
  const res = await fetch(`${API_BASE}/register_node`, {
    method: "POST",
    body: fd
  });
  render(box, await res.json());
}

async function loadNodes() {
  const box = document.getElementById("nodeBox");
  box.innerHTML = "Memuat peer...";
  const res = await fetch(`${API_BASE}/nodes`);
  box.textContent = JSON.stringify(await res.json(), null, 2);
}

async function loadSummary() {
  const box = document.getElementById("summaryBox");
  box.innerHTML = "Memuat ringkasan ledger...";

  const res = await fetch(`${API_BASE}/summary`);
  const data = await res.json();

  box.innerHTML = `
    <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
      <div class="bg-slate-950 border border-slate-700 rounded p-4">
        <p class="text-xs text-slate-400">File ZIP Terdaftar</p>
        <p class="text-2xl font-bold">${data.files_registered}</p>
      </div>
      <div class="bg-slate-950 border border-slate-700 rounded p-4">
        <p class="text-xs text-slate-400">Total Block</p>
        <p class="text-2xl font-bold">${data.total_blocks}</p>
      </div>
      <div class="bg-slate-950 border border-slate-700 rounded p-4">
        <p class="text-xs text-slate-400">Status Blockchain</p>
        <p class="text-2xl font-bold">${data.blockchain_valid ? "Valid" : "Tidak Valid"}</p>
      </div>
      <div class="bg-slate-950 border border-slate-700 rounded p-4 md:col-span-3">
        <p class="text-xs text-slate-400">Sampel Hash, Merkle Root, dan Block Hash</p>
        <pre class="text-xs overflow-x-auto">${JSON.stringify(data.files_keys_sample, null, 2)}</pre>
      </div>
    </div>
  `;
}

async function downloadFile() {
  const hash = document.getElementById("downloadHashInput").value.trim();
  const box = document.getElementById("downloadResult");

  if (!hash) {
    box.innerHTML = "Hash SHA-256 wajib diisi.";
    return;
  }

  box.innerHTML = "Membangun ulang ZIP dari chunk P2P lokal...";

  try {
    const res = await fetch(`${API_BASE}/download/${hash}`);
    if (!res.ok) {
      const err = await res.json();
      box.innerHTML = err.detail || "Download gagal.";
      return;
    }

    const blob = await res.blob();
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `${hash}.zip`;
    document.body.appendChild(a);
    a.click();
    a.remove();
    window.URL.revokeObjectURL(url);

    box.innerHTML = "File ZIP berhasil dibangun ulang dan diunduh.";
  } catch (e) {
    box.innerHTML = "Download gagal.";
  }
}

window.addEventListener("DOMContentLoaded", () => {
  if (window.lucide) {
    window.lucide.createIcons();
  }
  loadSummary();
  loadNodes();
});
